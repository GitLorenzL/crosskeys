using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class ApplyInput : MonoBehaviour {
    private String testText = "the springs festival is the most important festival of china. people always exchange gifts and wish harmony to others. ";

    public GameObject InputField;
    public GameObject Camera;
    public InputField field;
    public GameObject PrimaryCandidate, SecondCandidate, ThirdCandidate;
    public GameObject TestBoard, TestText;

    void resetRotationAndPosition() {
        InputField.transform.rotation = Camera.transform.rotation;
        InputField.transform.TransformDirection(Camera.transform.forward);
        InputField.transform.position = Camera.transform.position;
        InputField.transform.Translate(new Vector3(0, 0, 80f));

        
        PrimaryCandidate.transform.rotation = Camera.transform.rotation;
        PrimaryCandidate.transform.TransformDirection(Camera.transform.forward);
        PrimaryCandidate.transform.position = Camera.transform.position;
        PrimaryCandidate.transform.Translate(new Vector3(0, -6, 80f));
        
        SecondCandidate.transform.rotation = Camera.transform.rotation;
        SecondCandidate.transform.TransformDirection(Camera.transform.forward);
        SecondCandidate.transform.position = Camera.transform.position;
        SecondCandidate.transform.Translate(new Vector3(-18, -6, 80f));
        
        ThirdCandidate.transform.rotation = Camera.transform.rotation;
        ThirdCandidate.transform.TransformDirection(Camera.transform.forward);
        ThirdCandidate.transform.position = Camera.transform.position;
        ThirdCandidate.transform.Translate(new Vector3(18, -6, 80f));

        TestBoard.transform.rotation = Camera.transform.rotation;
        TestBoard.transform.TransformDirection(Camera.transform.forward);
        TestBoard.transform.position = Camera.transform.position;
        TestBoard.transform.Translate(new Vector3(0, 9.4f, 80f));
    }

    IEnumerator MoveCursorToTheTail() 
    {
        yield return new WaitForEndOfFrame();
        field.MoveTextEnd(true);
    }
    void activateField() {
        if (!field.isFocused) {
            field.ActivateInputField();
        }
        StartCoroutine(MoveCursorToTheTail());
    }

    void Start() { 
        field = GameObject.Find("InputField").GetComponent<InputField>();
        Camera = GameObject.Find("Camera (eye)");
        InputField = GameObject.Find("InputField");
        PrimaryCandidate = GameObject.Find("PrimaryCandidate");
        SecondCandidate = GameObject.Find("SecondCandidate");
        ThirdCandidate = GameObject.Find("ThirdCandidate");
        TestBoard = GameObject.Find("TestBoard");
        TestText = GameObject.Find("TestText");

        TestText.GetComponent<Text>().text = testText;

        resetRotationAndPosition();
        activateField();
    }

    void Update() {
        TestText.GetComponent<Text>().text = testText;

        resetRotationAndPosition();
        activateField();
    }
}